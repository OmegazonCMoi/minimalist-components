import { defineConfig } from "tsup";

export default defineConfig({
  entry: ["app/index.ts"],
  tsconfig: "tsconfig.lib.json",
  format: ["esm", "cjs"],
  dts: true,
  clean: true,
  external: [
    "react",
    "react-dom",
    "framer-motion",
    "lucide-react",
  ],
});